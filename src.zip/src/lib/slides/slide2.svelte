<script>
  import { browser } from '$app/environment';
  import TopGamesBarChart from '$lib/components/slide1.2.svelte'; // Bar chart
  import Chart1 from '$lib/components/slide1.1.svelte'; // Donut chart

  export let steamId = '';

  let loading = false;
  let error = '';
  let topGames = [];

  async function loadTopGames() {
    if (!steamId) {
      error = 'Geen SteamID geselecteerd. Ga eerst naar slide 1.';
      topGames = [];
      return;
    }

    loading = true;
    error = '';
    topGames = [];

    try {
      const res = await fetch(`/api/top-games?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok) {
        error = json.error || 'Kon top games niet laden.';
      } else {
        topGames = json.topGames || [];
      }
    } catch (e) {
      console.error(e);
      error = 'Netwerkfout bij het laden van top games.';
    } finally {
      loading = false;
    }
  }

  // reageer op veranderingen in steamId – maar alleen in de browser
  $: if (browser && steamId) {
    loadTopGames();
  }
</script>

<div class="slide2">
  <h2>Top 5 meest gespeelde games</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>
  {:else if loading}
    <p>Top games laden…</p>
  {:else if error}
    <p class="error">{error}</p>
  {:else if topGames.length === 0}
    <p>Geen games gevonden voor dit account.</p>
  {:else}
    <div class="charts">
      <div class="chart-block">
        <h3>Speeltijd per game (uren)</h3>
        <TopGamesBarChart data={topGames} />
      </div>
      <div class="chart-block">
        <h3>Verdeling speeltijd (donut)</h3>
        <Chart1 data={topGames} width={360} height={360} />
      </div>
    </div>
  {/if}
</div>

<style>
  .slide2 {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .charts {
    display: flex;
    flex-wrap: wrap;
    gap: 2rem;
    align-items: flex-start;
  }

  .chart-block {
    flex: 1 1 320px;
  }

  .error {
    color: #f88;
  }
</style>
