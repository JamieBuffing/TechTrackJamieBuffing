<script>
  import { browser } from '$app/environment';
  import LibraryValueChart from '$lib/components/slide7.1.svelte';

  export let steamId = '';

  let loading = false;
  let error = '';
  let totalValue = 0;
  let currency = 'EUR';
  let gamesPricedCount = 0;
  let totalOwnedCount = 0;
  let genres = [];
  let mostExpensive = [];
  let lastSteamIdLoaded = '';

  async function loadLibraryValue() {
    if (!steamId) {
      error = 'Geen SteamID geselecteerd.';
      return;
    }

    loading = true;
    error = '';
    genres = [];
    mostExpensive = [];
    totalValue = 0;
    gamesPricedCount = 0;
    totalOwnedCount = 0;

    try {
      const res = await fetch(`/api/library-value?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok) {
        error = json.error || 'Kon library waarde niet laden.';
      } else {
        if (json.message && (!json.genres || !json.genres.length)) {
          error = json.message;
        }
        totalValue = json.totalValue || 0;
        currency = json.currency || 'EUR';
        gamesPricedCount = json.gamesPricedCount || 0;
        totalOwnedCount = json.totalOwnedCount || 0;
        genres = json.genres || [];
        mostExpensive = json.mostExpensive || [];
      }
    } catch (e) {
      console.error(e);
      error = 'Netwerkfout bij het laden van library waarde.';
    } finally {
      loading = false;
    }
  }

  $: if (browser && steamId && steamId !== lastSteamIdLoaded) {
    lastSteamIdLoaded = steamId;
    loadLibraryValue();
  }

  function formatCurrency(amount) {
    return `${amount.toFixed(2)} ${currency}`;
  }
</script>

<div class="slide8">
  <h2>Waardeverdeling van je library</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>
  {:else if loading}
    <p>Library waarde laden…</p>
  {:else if error && (!genres || genres.length === 0)}
    <p class="error">{error}</p>
  {:else}
    <div class="summary">
      <div class="summary-block big">
        <div class="label">Geschatte waarde (subset)</div>
        <div class="value">{formatCurrency(totalValue)}</div>
        <div class="note">
          Gebaseerd op ongeveer {gamesPricedCount} games met prijsinformatie
          van je totaal {totalOwnedCount} games.
        </div>
      </div>
    </div>
    
    {#if genres && genres.length}
      <div class="section">
        <h3>Verdeling per genre / categorie</h3>
        <p class="hint">
          Hier zie je hoeveel van de totale waarde gekoppeld is aan elke genre/categorie
          op de store-pagina. Dit zijn de genres van de games waar een actuele
          prijs voor gevonden is.
        </p>
        <LibraryValueChart data={genres} {currency} />
      </div>
    {/if}

    {#if mostExpensive && mostExpensive.length}
      <div class="section">
        <h3>Duurste games in je library</h3>
        <p class="hint">
          Dit zijn de games met de hoogste huidige store-prijs in de subset die is opgehaald.
        </p>
        <table class="games-table">
          <thead>
            <tr>
              <th>Game</th>
              <th>Prijs</th>
              <th>Jouw speeltijd</th>
            </tr>
          </thead>
          <tbody>
            {#each mostExpensive as g}
              <tr>
                <td>{g.name}</td>
                <td>{formatCurrency(g.price)}</td>
                <td>{g.hours}u</td>
              </tr>
            {/each}
          </tbody>
        </table>
      </div>
    {/if}
  {/if}
</div>

<style>
  .slide8 {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .summary {
    display: flex;
    flex-wrap: wrap;
    gap: 1rem;
  }

  .summary-block {
    background: #171a21;
    border-radius: 0.75rem;
    border: 1px solid #2a475e;
    padding: 0.75rem 1rem;
  }

  .summary-block.big {
    flex: 1 1 260px;
  }

  .label {
    font-size: 0.85rem;
    color: #ccc;
  }

  .value {
    font-size: 1.4rem;
    font-weight: 600;
    margin-top: 0.2rem;
  }

  .note {
    margin-top: 0.2rem;
    font-size: 0.8rem;
    color: #aaa;
  }

  .section {
    margin-top: 0.5rem;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }

  .hint {
    font-size: 0.85rem;
    color: #ccc;
  }

  .games-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.85rem;
    margin-top: 0.25rem;
  }

  .games-table th,
  .games-table td {
    padding: 0.35rem 0.5rem;
    border-bottom: 1px solid #2a475e;
  }

  .games-table th {
    text-align: left;
    font-weight: 500;
    color: #ccc;
  }

  .games-table td {
    color: #eee;
  }

  .error {
    color: #ff7777;
  }
</style>
