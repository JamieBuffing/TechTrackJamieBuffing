<script>
  import { browser } from '$app/environment';
  import RadialProgress from '$lib/components/slide4.1.svelte';

  export let steamId = '';

  let loadingGames = false;
  let gamesError = '';
  let games = [];
  let loadedGamesForSteamId = '';

  let selectedAppId = '';
  let selectedGameName = '';

  let loadingAchievements = false;
  let achError = '';
  let achData = null;
  let lastAppIdLoaded = '';

  let filter = 'all'; // 'all' | 'unlocked' | 'locked'

  async function loadGames() {
    if (!steamId) {
      gamesError = 'Geen SteamID geselecteerd.';
      games = [];
      return;
    }

    loadingGames = true;
    gamesError = '';
    games = [];

    try {
      const res = await fetch(`/api/top-games?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok) {
        gamesError = json.error || 'Kon games niet laden.';
      } else {
        games = json.topGames || [];
        if (games.length && !selectedAppId) {
          selectedAppId = String(games[0].appid);
          selectedGameName = games[0].name;
        }
      }
    } catch (e) {
      console.error(e);
      gamesError = 'Netwerkfout bij het laden van games.';
    } finally {
      loadingGames = false;
    }
  }

  async function loadAchievements() {
    if (!steamId || !selectedAppId) return;

    loadingAchievements = true;
    achError = '';
    achData = null;

    try {
      const res = await fetch(
        `/api/achievements?steamid=${steamId}&appid=${selectedAppId}`
      );
      const json = await res.json();

      if (!res.ok) {
        achError = json.error || 'Kon achievements niet laden.';
      } else if (json.total === 0) {
        achError = json.message || 'Deze game heeft geen achievements.';
      } else {
        achData = json;
      }
    } catch (e) {
      console.error(e);
      achError = 'Netwerkfout bij het laden van achievements.';
    } finally {
      loadingAchievements = false;
    }
  }

  // games laden als steamId verandert (alleen in browser)
  $: if (browser && steamId && steamId !== loadedGamesForSteamId) {
    loadedGamesForSteamId = steamId;
    selectedAppId = '';
    selectedGameName = '';
    achData = null;
    loadGames();
  }

  // achievements laden als geselecteerde app verandert
  $: if (browser && steamId && selectedAppId && selectedAppId !== lastAppIdLoaded) {
    lastAppIdLoaded = selectedAppId;
    loadAchievements();
  }

  function onSelectChange(event) {
    const appid = event.target.value;
    selectedAppId = appid;
    const g = games.find((game) => String(game.appid) === appid);
    selectedGameName = g ? g.name : '';
  }

  $: allAchievements = achData ? achData.achievements : [];
  $: unlocked = allAchievements.filter((a) => a.achieved);
  $: locked = allAchievements.filter((a) => !a.achieved);

  $: filteredAchievements =
    filter === 'unlocked'
      ? unlocked
      : filter === 'locked'
      ? locked
      : allAchievements;

  function setFilter(f) {
    filter = f;
  }
</script>

<div class="slide6">
  <h2>Achievement overzicht – favoriete game</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>
  {:else}
    <div class="controls">
      <label>
        Kies je favoriete game:
        <select bind:value={selectedAppId} on:change={onSelectChange}>
          {#if loadingGames}
            <option disabled>Games laden…</option>
          {:else if gamesError}
            <option disabled>{gamesError}</option>
          {:else if games.length === 0}
            <option disabled>Geen games gevonden.</option>
          {:else}
            {#each games as g}
              <option value={g.appid}>{g.name}</option>
            {/each}
          {/if}
        </select>
      </label>
    </div>

    {#if loadingAchievements}
      <p>Achievements laden…</p>
    {:else if achError}
      <p class="error">{achError}</p>
    {:else if achData}
      <div class="header">
        <div class="progress-block">
          <RadialProgress
            value={achData.percentage}
            label="Unlocked"
            sublabel={`${achData.unlocked} / ${achData.total} achievements`}
          />
        </div>
        <div class="meta-block">
          <h3>{selectedGameName}</h3>
          <p class="hint">
            Dit is een volledig overzicht van alle achievements voor deze game.
            Gebruik de filters hieronder om alleen unlocked of locked te bekijken.
          </p>

          <div class="filters">
            <button
              type="button"
              class:selected={filter === 'all'}
              on:click={() => setFilter('all')}
            >
              Alle ({allAchievements.length})
            </button>
            <button
              type="button"
              class:selected={filter === 'unlocked'}
              on:click={() => setFilter('unlocked')}
            >
              Unlocked ({unlocked.length})
            </button>
            <button
              type="button"
              class:selected={filter === 'locked'}
              on:click={() => setFilter('locked')}
            >
              Locked ({locked.length})
            </button>
          </div>
        </div>
      </div>

      <div class="grid">
        {#if filteredAchievements.length === 0}
          <p class="muted">Geen achievements in deze filter.</p>
        {:else}
          {#each filteredAchievements as a}
            <div class="card {a.achieved ? 'unlocked' : 'locked'}">
              <div class="card-header">
                {#if a.achieved && a.icon}
                  <img src={a.icon} alt="" class="ach-icon" />
                {:else if !a.achieved && a.icongray}
                  <img src={a.icongray} alt="" class="ach-icon" />
                {/if}
                <div class="titles">
                  <div class="name">{a.displayName}</div>
                  {#if a.description}
                    <div class="desc">{a.description}</div>
                  {/if}
                </div>
              </div>
              <div class="tags">
                {#if a.hidden}
                  <span class="tag secret">Secret</span>
                {/if}
                <span class="tag {a.achieved ? 'tag-unlocked' : 'tag-locked'}">
                  {a.achieved ? 'Unlocked' : 'Locked'}
                </span>
              </div>
            </div>
          {/each}
        {/if}
      </div>
    {/if}
  {/if}
</div>

<style>
  .slide6 {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .controls {
    margin-bottom: 0.5rem;
  }

  select {
    margin-left: 0.5rem;
    background: #1b2838;
    color: #fff;
    border-radius: 0.4rem;
    border: 1px solid #2a475e;
    padding: 0.25rem 0.5rem;
    font-size: 0.9rem;
  }

  .header {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
    align-items: center;
  }

  .progress-block {
    flex: 0 0 auto;
  }

  .meta-block {
    flex: 1 1 260px;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }

  .hint {
    font-size: 0.85rem;
    color: #ccc;
  }

  .filters {
    display: flex;
    gap: 0.5rem;
    flex-wrap: wrap;
  }

  .filters button {
    background: #171a21;
    border-radius: 999px;
    border: 1px solid #2a475e;
    padding: 0.25rem 0.8rem;
    font-size: 0.8rem;
    color: #f5f5f5;
    cursor: pointer;
  }

  .filters button.selected {
    background: #66c0f4;
    border-color: #66c0f4;
    color: #171a21;
  }

  .grid {
    margin-top: 1rem;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(230px, 1fr));
    gap: 0.75rem;
  }

  .card {
    background: #171a21;
    border-radius: 0.75rem;
    border: 1px solid #2a475e;
    padding: 0.6rem 0.7rem;
    display: flex;
    flex-direction: column;
    gap: 0.4rem;
  }

  .card.unlocked {
    border-color: #66c0f4;
  }

  .card.locked {
    opacity: 0.8;
  }

  .card-header {
    display: flex;
    gap: 0.5rem;
  }

  .ach-icon {
    width: 40px;
    height: 40px;
    border-radius: 0.25rem;
    flex-shrink: 0;
  }

  .titles {
    display: flex;
    flex-direction: column;
  }

  .name {
    font-size: 0.9rem;
    font-weight: 500;
  }

  .desc {
    font-size: 0.8rem;
    color: #bbb;
  }

  .tags {
    display: flex;
    gap: 0.35rem;
    flex-wrap: wrap;
  }

  .tag {
    font-size: 0.7rem;
    padding: 0.1rem 0.5rem;
    border-radius: 999px;
    border: 1px solid #2a475e;
  }

  .tag-unlocked {
    border-color: #66c0f4;
    color: #66c0f4;
  }

  .tag-locked {
    border-color: #888;
    color: #888;
  }

  .secret {
    border-color: #f1c40f;
    color: #f1c40f;
  }

  .muted {
    font-size: 0.85rem;
    color: #aaa;
  }

  .error {
    color: #ff7777;
  }
</style>
