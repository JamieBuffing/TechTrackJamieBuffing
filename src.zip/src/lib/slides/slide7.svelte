<script>
  import { browser } from '$app/environment';
  import HiddenGemsList from '$lib/components/slide6.1.svelte';

  export let steamId = '';

  let loading = false;
  let error = '';
  let gems = [];
  let lastSteamIdLoaded = '';

  async function loadHiddenGems() {
    if (!steamId) {
      error = 'Geen SteamID geselecteerd.';
      gems = [];
      return;
    }

    loading = true;
    error = '';
    gems = [];

    try {
      const res = await fetch(`/api/hidden-gems?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok || json.error) {
        error = json.error || 'Kon hidden gems niet laden.';
      } else {
        gems = json.gems || [];
        if (!gems.length && json.message) {
          error = json.message;
        }
      }
    } catch (e) {
      console.error(e);
      error = 'Netwerkfout bij het laden van hidden gems.';
    } finally {
      loading = false;
    }
  }

  $: if (browser && steamId && steamId !== lastSteamIdLoaded) {
    lastSteamIdLoaded = steamId;
    loadHiddenGems();
  }
</script>

<div class="slide7">
  <h2>Hidden gems in je library</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>

  {:else if loading}
    <p>Hidden gems zoeken…</p>

  {:else if error && (!gems || gems.length === 0)}
    <p class="error">{error}</p>

  {:else if gems.length === 0}
    <p class="muted">
      We konden geen hidden gems vinden. Misschien speel je alles al heel uitgebreid,
      of zijn er weinig games met voldoende reviews.
    </p>

  {:else}
    <p class="intro">
      Dit zijn games die jij relatief weinig hebt gespeeld, maar op Steam een sterke
      beoordeling en/of veel positieve reviews hebben. Hun <strong>hidden gem score</strong>
      combineert reviewscore, populariteit en het feit dat jij ze nog weinig hebt aangeraakt.
    </p>

    <HiddenGemsList data={gems} />
  {/if}
</div>

<style>
  .slide7 {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .intro {
    font-size: 0.9rem;
    color: #ccc;
  }

  .muted {
    font-size: 0.85rem;
    color: #aaa;
  }

  .error {
    color: #ff7777;
  }
</style>
