<!-- src/lib/slides/slide3.svelte -->
<script>
  import { browser } from '$app/environment';
  import GenreIconsChart from '$lib/components/slide3.1.svelte';

  export let steamId = '';
  export let isActive = false;

  let loading = false;
  let error = '';
  let genres = [];
  let lastSteamIdLoaded = '';

  async function loadGenres() {
    if (!steamId) {
      error = 'Geen SteamID geselecteerd. Ga eerst naar slide 1.';
      genres = [];
      return;
    }

    loading = true;
    error = '';
    genres = [];

    try {
      const res = await fetch(`/api/genres?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok || json.error) {
        error = json.error || 'Kon genres niet laden.';
      } else {
        genres = json.genres || [];
        if (!genres.length && json.message) {
          error = json.message;
        }
      }
    } catch (e) {
      console.error(e);
      error = 'Netwerkfout bij het laden van genres.';
    } finally {
      loading = false;
    }
  }

  // laad genres als steamId verandert (alleen in browser)
  $: if (browser && isActive && steamId && steamId !== lastSteamIdLoaded) {
    lastSteamIdLoaded = steamId;
    loadGenres();
  }
</script>

<div class="slide3">
  <h2>Genre / categorie verdeling</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>

  {:else if loading}
    <p>Genres laden…</p>

  {:else if error && (!genres || genres.length === 0)}
    <p class="error">{error}</p>

  {:else if genres.length === 0}
    <p>Geen genres/categorieën gevonden.</p>

  {:else}
    <p class="intro">
      Dit is een overzicht van je belangrijkste genres/categorieën op basis van
      de <strong>voornaamste categorie per game</strong>. Alle speeltijd van een game
      wordt toegewezen aan die hoofdcategorie.
      Hover over een rij om te zien welke games daar allemaal in zitten.
    </p>

    <GenreIconsChart data={genres} />
  {/if}
</div>

<style>
  .slide3 {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .intro {
    font-size: 0.9rem;
    color: #ccc;
  }

  .error {
    color: #ff7777;
  }
</style>
