<script>
  import { browser } from '$app/environment';
  import RadialProgress from '$lib/components/slide4.1.svelte';

  export let steamId = '';

  let loadingGames = false;
  let gamesError = '';
  let games = [];
  let loadedGamesForSteamId = '';

  let selectedAppId = '';
  let selectedGameName = '';

  let loadingAchievements = false;
  let achError = '';
  let achData = null;
  let lastAppIdLoaded = '';

  async function loadGames() {
    if (!steamId) {
      gamesError = 'Geen SteamID geselecteerd.';
      games = [];
      return;
    }

    loadingGames = true;
    gamesError = '';
    games = [];

    try {
      const res = await fetch(`/api/top-games?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok) {
        gamesError = json.error || 'Kon games niet laden.';
      } else {
        games = json.games || json.topGames || [];
        if (games.length && !selectedAppId) {
          selectedAppId = String(games[0].appid);
          selectedGameName = games[0].name;
        }
      }
    } catch (e) {
      console.error(e);
      gamesError = 'Netwerkfout bij het laden van games.';
    } finally {
      loadingGames = false;
    }
  }

  async function loadAchievements() {
    if (!steamId || !selectedAppId) return;

    loadingAchievements = true;
    achError = '';
    achData = null;

    try {
      const res = await fetch(
        `/api/achievements?steamid=${steamId}&appid=${selectedAppId}`
      );
      const json = await res.json();

      if (!res.ok) {
        achError = json.error || 'Kon achievements niet laden.';
      } else if (json.total === 0) {
        achError =
          json.message || 'Deze game heeft geen achievements.';
      } else {
        achData = json;
      }
    } catch (e) {
      console.error(e);
      achError = 'Netwerkfout bij het laden van achievements.';
    } finally {
      loadingAchievements = false;
    }
  }

  // games laden als steamId verandert (alleen in browser)
  $: if (browser && steamId && steamId !== loadedGamesForSteamId) {
    loadedGamesForSteamId = steamId;
    loadGames();
  }

  // achievements laden als geselecteerde app verandert
  $: if (browser && steamId && selectedAppId && selectedAppId !== lastAppIdLoaded) {
    lastAppIdLoaded = selectedAppId;
    loadAchievements();
  }

  function onSelectChange(event) {
    const appid = event.target.value;
    selectedAppId = appid;
    const g = games.find((game) => String(game.appid) === appid);
    selectedGameName = g ? g.name : '';
  }

  $: unlocked = achData
    ? achData.achievements.filter((a) => a.achieved)
    : [];
  $: locked = achData
    ? achData.achievements.filter((a) => !a.achieved)
    : [];
</script>

<div class="slide4">
  <h2>Achievement progress</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>
  {:else}
    <div class="controls">
      <label>
        Kies een game:
        <select bind:value={selectedAppId} on:change={onSelectChange}>
          {#if loadingGames}
            <option disabled>Games laden…</option>
          {:else if gamesError}
            <option disabled>{gamesError}</option>
          {:else if games.length === 0}
            <option disabled>Geen games gevonden.</option>
          {:else}
            {#each games as g}
              <option value={g.appid}>{g.name}</option>
            {/each}
          {/if}
        </select>
      </label>
    </div>

    {#if loadingAchievements}
      <p>Achievements laden…</p>
    {:else if achError}
      <p class="error">{achError}</p>
    {:else if achData}
      <div class="content">
        <div class="left">
          <RadialProgress
            value={achData.percentage}
            label="Unlocked"
            sublabel={`${achData.unlocked} / ${achData.total} achievements`}
          />
        </div>

        <div class="right">
          <h3>{selectedGameName}</h3>

          <div class="ach-section">
            <h4>Unlocked ({unlocked.length})</h4>
            {#if unlocked.length === 0}
              <p class="muted">Nog geen achievements unlocked.</p>
            {:else}
              <ul class="ach-list">
                {#each unlocked as a}
                  <li>
                    {#if a.icon}
                      <img src={a.icon} alt="" class="ach-icon" />
                    {/if}
                    <div class="ach-text">
                      <div class="ach-name">{a.displayName}</div>
                      {#if a.description}
                        <div class="ach-desc">{a.description}</div>
                      {/if}
                    </div>
                  </li>
                {/each}
              </ul>
            {/if}
          </div>

          <div class="ach-section">
            <h4>Locked ({locked.length})</h4>
            {#if locked.length === 0}
              <p class="muted">Alles unlocked! 🔥</p>
            {:else}
              <ul class="ach-list">
                {#each locked as a}
                  <li class="locked">
                    {#if a.icongray}
                      <img src={a.icongray} alt="" class="ach-icon" />
                    {/if}
                    <div class="ach-text">
                      <div class="ach-name">{a.displayName}</div>
                      {#if a.description}
                        <div class="ach-desc">{a.description}</div>
                      {/if}
                    </div>
                  </li>
                {/each}
              </ul>
            {/if}
          </div>
        </div>
      </div>
    {/if}
  {/if}
</div>

<style>
  .slide4 {
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .controls {
    margin-bottom: 0.5rem;
  }

  select {
    margin-left: 0.5rem;
    background: #1b2838;
    color: #fff;
    border-radius: 0.4rem;
    border: 1px solid #2a475e;
    padding: 0.25rem 0.5rem;
    font-size: 0.9rem;
  }

  .content {
    display: flex;
    flex-wrap: wrap;
    gap: 1.5rem;
  }

  .left {
    flex: 0 0 auto;
  }

  .right {
    flex: 1 1 260px;
    display: flex;
    flex-direction: column;
    gap: 1rem;
  }

  .ach-section h4 {
    margin: 0 0 0.25rem;
  }

  .ach-list {
    list-style: none;
    padding: 0;
    margin: 0;
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
    max-height: 260px;
    overflow-y: auto;
  }

  .ach-list li {
    display: flex;
    gap: 0.5rem;
    align-items: center;
    padding: 0.25rem 0.35rem;
    border-radius: 0.4rem;
    background: rgba(23, 26, 33, 0.9);
  }

  .ach-list li.locked {
    opacity: 0.7;
  }

  .ach-icon {
    width: 32px;
    height: 32px;
    border-radius: 0.2rem;
  }

  .ach-text {
    display: flex;
    flex-direction: column;
  }

  .ach-name {
    font-size: 0.9rem;
    font-weight: 500;
  }

  .ach-desc {
    font-size: 0.8rem;
    color: #bbb;
  }

  .muted {
    font-size: 0.85rem;
    color: #aaa;
  }

  .error {
    color: #ff7777;
  }
</style>
