<script>
  import { browser } from '$app/environment';
  import SteamBubbleGalaxy from '$lib/components/slide8.1.svelte';

  export let steamId = '';

  let loading = false;
  let error = '';
  let games = [];
  let lastLoadedSteamId = '';

  async function loadGames() {
    if (!steamId) {
      error = 'Geen SteamID geselecteerd.';
      games = [];
      return;
    }

    loading = true;
    error = '';
    games = [];

    try {
      const res = await fetch(`/api/owned-games-simple?steamid=${steamId}`);
      const json = await res.json();

      if (!res.ok || json.error) {
        error = json.error || 'Kon games niet laden.';
      } else {
        games = json.games || [];
      }
    } catch (e) {
      console.error(e);
      error = 'Netwerkfout bij het laden van je games.';
    } finally {
      loading = false;
    }
  }

  // laad data als steamId verandert (alleen in browser)
  $: if (browser && steamId && steamId !== lastLoadedSteamId) {
    lastLoadedSteamId = steamId;
    loadGames();
  }
</script>

<div class="slide9">
  <h2>Jouw Steam speeluniversum</h2>

  {#if !steamId}
    <p>Geen SteamID geselecteerd. Ga terug naar slide 1 om een account te kiezen.</p>

  {:else if loading}
    <p>Je speeluniversum wordt opgebouwd…</p>

  {:else if error}
    <p class="error">{error}</p>

  {:else if games.length === 0}
    <p>We vonden geen games met speeltijd. Start een game en kom later terug 😉</p>

  {:else}
    <p class="hint">
      Elke cirkel is een game die je gespeeld hebt. Hoe groter de bubbel, hoe meer uur je erin hebt gestoken.
      Beweeg met je muis over een bubbel om te zien welke game het is.
      Je kunt de bubbles ook een beetje verslepen.
    </p>

    <SteamBubbleGalaxy data={games} width={700} height={450} />

    <p class="footer">
      Dit is de laatste slide van je Steam Story – een overzicht van alle werelden waar je tijd in hebt geïnvesteerd.
    </p>
  {/if}
</div>

<style>
  .slide9 {
    display: flex;
    flex-direction: column;
    gap: 0.75rem;
  }

  h2 {
    margin: 0;
  }

  .hint {
    font-size: 0.85rem;
    color: #c0c6d2;
    max-width: 620px;
  }

  .footer {
    margin-top: 0.5rem;
    font-size: 0.85rem;
    color: #9ca9c6;
  }

  .error {
    color: #ff7777;
  }
</style>
